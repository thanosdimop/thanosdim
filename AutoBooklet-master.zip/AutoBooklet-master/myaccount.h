#include <iostream>
#include <cstdlib>
#include <string>
#include "AddCar.h"




class MyAccount{
	public:
		AddCar A;
        void Add_car();
        int x;

};
