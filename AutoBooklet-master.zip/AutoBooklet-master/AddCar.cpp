#include "AddCar.h"


using namespace std;

void AddCar::add_plate(){
		cout<<"eisagete ari8mo plaisiou: ";
		cin>> frame_number;
	}
void AddCar::add_brand(){
		cout<<"eisagete marka: ";
		cin>>car_brand;
		cout<<"eisagete modelo: ";
		cin>>car_model;
	}
void AddCar::add_odo(){
		cout<<"eisagete xiliometra: ";
		cin>>odometre;
	}

