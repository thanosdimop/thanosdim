#include <iostream>
#include <cstdlib>
#include <string>


using namespace std;

class OnlineMarket{
public:
int category;
int product;
char product_detail;
void select_category();
void select_product(int category);
};
