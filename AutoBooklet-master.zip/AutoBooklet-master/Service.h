#include <iostream>
#include <cstdlib>
#include <string>


class Service{
	public:

		int programmed_service;
		int file;
		void Select_service();
};
